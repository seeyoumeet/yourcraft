----------------------------------------
------------- FLAN'S MOD ---------------
------ AND FLAN'S MOD: APOCALYPSE ------
----------------------------------------

To install, drop the contents of this zip into your game folder.
You will need Minecraft 1.12.2 and Forge 2611 or later!

To add additional content packs (Modern weapons, WW2, FutureCraft and loads more) browse my website at http://flansmod.com/content-packs
and place the packs in the newly created "Flan" folder.

To get to the Apocalypse, craft an AI Chip and build a mecha with it : https://www.youtube.com/watch?v=yRe9MWV2rXI

Enjoy!

----------------------------------------

Bugs, comments and suggestions can be given at https://github.com/FlansMods/FlansMod/issues